add = lambda num: num + 4
print(add(6))