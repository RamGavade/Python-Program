from nltk import sent_tokenize
sent = "Hey I am Ram. It is one of the best for Computer Science students."
print(sent_tokenize(sent))