from nltk import word_tokenize
sent = "Hey I am Ram. It is one of the best for Computer Science students."
print(word_tokenize(sent))