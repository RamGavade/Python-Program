str="Javapoint"
print(str[1:5])
print(str[0:5])
print(str[:5])
print(str[1:])
print(str[-5:-1])
print(str[::-1])

