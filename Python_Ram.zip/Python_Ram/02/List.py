list1=[1,2,"Python","Programs",10.3]
list2=["Amy","Ryan","Python","Programs","Emma"]
print(list1)
print(list2)
