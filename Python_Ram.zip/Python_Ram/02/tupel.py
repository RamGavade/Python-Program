tuple1=(1,2,3,4,5,6,7,8,9)
for value in tuple1:
    if value % 2 !=0:
        print(value)
else:
    print("This are odd number present in tuple")