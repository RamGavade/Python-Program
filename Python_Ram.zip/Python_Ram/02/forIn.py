s="Geeks"
for i in s:
    print(i)