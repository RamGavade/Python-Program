def for_loop_example():
    n=int(input("Enter Number"))
    for i in range(0,n+1):
        print(i)
for_loop_example()