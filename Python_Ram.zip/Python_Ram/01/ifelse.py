num=int(input("Enter Number : "))
if num%2==0 :
    print("Number is Even")
else :
    print("Number is odd")
